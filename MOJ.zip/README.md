# MOJ
project was created using 
Java and Eclipse ide

Running the application
------------------------
1. download into a local computer and inport into your ide.
2. To run right click on application folder and run on server.
3. when a web page is presented enter name and click send button.
